export const metadata = {
  title: "XAI FINANCE",
  description: "安全高效的加密货币管理平台",
  generator: 'v0.dev',
  icons: {
    icon: '/logo.png',
    apple: '/logo.png',
  }
} 